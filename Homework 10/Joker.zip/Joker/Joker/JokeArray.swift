//
//  JokeArray.swift
//  Joker
//
//  Created by Alexander Lao on 2/11/17.
//  Copyright © 2017 Alexander Lao. All rights reserved.
//

import Foundation

class JokeArray
{
    var jokes = [Joke]()
    
    init ()
    {
        self.jokes = [Joke]();
    }
}
